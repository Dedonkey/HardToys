#pragma once
#include<iostream>
#include<fstream>
#include"PageRank.h"

enum MODE { START, OUTLINK };

int Input(std::ifstream &ifs, char *buf, int max);

int Judge(std::string &str, std::map<std::string, PRC> &m,std::string &lasturl);

int Proc(std::ifstream &ifs, std::map<std::string, PRC> &m);