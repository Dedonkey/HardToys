#pragma once
#include<map>
#include<string>


const double a = 0.85;

class PRC
{
private:
	std::string url;
	double pr;
public:
	enum INWHERE{TOIN,TOOUT};
	std::map<std::string, int> in;
	std::map<std::string, int> out;
	PRC();
	PRC(std::string str);
	int Insert(std::string str, INWHERE w);
	std::string Geturl();
	double Getpr();
	int Modipr(double value);

};

int Calculator(std::map<std::string, PRC> &m);

