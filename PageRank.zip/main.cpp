#include<iostream>
#include<fstream>
#include<string>
#include"Input.h"
#include<map>
#include"PageRank.h"
#include<vector>
#include<algorithm>

bool Cmp(std::pair<std::string, double> p1, std::pair<std::string, double> p2)
{
	return p1.second > p2.second;
}

int Standard(std::vector<std::pair<std::string, double>> &vec);

int main()
{
	std::ifstream ifs;
	std::ofstream ofs;
	std::map<std::string, PRC>::iterator it;
	std::vector<std::pair<std::string,double>> vec;
	std::vector<std::pair<std::string, double>>::iterator it2;

	char path[] = "D:/Project/source/Project2/sohuc.txt";
	char path2[] = "D:/Project/source/Project2/res.txt";

	ifs.open(path);
	ofs.open(path2);
	std::map<std::string, PRC> m;

	Proc(ifs, m);
	for (int i = 0; i < 100; i++)
		Calculator(m);
	for (it = m.begin(); it != m.end(); it++)
		vec.push_back(std::pair<std::string,double>(it->first,it->second.Getpr()));
	std::sort(vec.begin(), vec.end(), Cmp);
	Standard(vec);
	for (it2 = vec.begin(); it2 != vec.end(); it2++)
		ofs << it2->first << "   prvalue:  " << it2->second << "\n";
	
	ifs.close(); ofs.close();
	system("pause");
	return 0;

}

int Standard(std::vector<std::pair<std::string, double>> &vec)
{
	double total = 0;
	std::vector<std::pair<std::string, double>>::iterator it;
	for (it = vec.begin(); it != vec.end(); it++)
		total+=it->second;
	for (it = vec.begin(); it != vec.end(); it++)
		it->second /= total;

	return 0;
}