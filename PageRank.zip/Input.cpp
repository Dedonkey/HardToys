#include"Input.h"


int Input(std::ifstream &ifs, std::string buf)
{
	getline(ifs, buf);
	return 0;
}

int Judge(std::string &str, std::map<std::string, PRC> &m,std::string &lasturl)
{
	std::size_t pos;
	std::string theurl;
	std::string url;
	std::map<std::string, PRC>::iterator it;
	if ((pos = str.find("WARC-Target-URI:")) != std::string::npos)
	{
		theurl = str.substr(pos + 17);
		theurl = theurl.substr(0, theurl.find(' '));

		m.insert(std::pair<std::string, PRC>(theurl, PRC(theurl)));
		lasturl = theurl;
		return 1;
	}
	if ((pos = str.find("outlink:")) != std::string::npos)
	{
		theurl = str.substr(pos + 9);
		theurl = theurl.substr(0, theurl.find(' '));
		it = m.find(lasturl);
		it->second.Insert(theurl, PRC::INWHERE::TOOUT);
		m.insert(std::pair<std::string, PRC>(theurl, PRC(lasturl)));
		it = m.find(theurl);
		it->second.Insert(it->second.Geturl(),PRC::INWHERE::TOIN);
		return 2;
	}
	else
	{
		if(str.find("href") != std::string::npos)
		{
			url = str.substr(str.find("href") + 6);
			url = url.substr(0,str.find("\""));
			
			it = m.find(lasturl);
			it->second.Insert(theurl, PRC::INWHERE::TOOUT);
			m.insert(std::pair<std::string, PRC>(theurl, PRC(lasturl)));
			it = m.find(theurl);
			it->second.Insert(it->second.Geturl(), PRC::INWHERE::TOIN);
			return 2;
		}
	}

	return 0;
}


int Proc(std::ifstream &ifs, std::map<std::string, PRC> &m)
{
	std::string lasturl;
	std::string buf;
	while (!ifs.eof())
	{
		getline(ifs, buf);
		Judge(buf, m, lasturl);
	}

	return 0;
}