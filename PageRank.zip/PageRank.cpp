#include"PageRank.h"

PRC::PRC()
{ 
	pr = 1.0;

	return; 
}

PRC::PRC(std::string str)
{
	url = str;
	pr = 1.0;

	return;
}

int PRC::Insert(std::string str, INWHERE w)
{
	std::map<std::string, int> ::iterator it;

	if (w == TOIN)
	{
		if (in.insert(std::pair<std::string, int>(str, 1)).second == false)
		{
			it = in.find(str);
			it->second++;
		}
	}
	else
	{
		if (out.insert(std::pair<std::string, int>(str, 1)).second == false)
		{
			it = out.find(str);
			it->second++;
		}
	}

	return 0;
}

std::string PRC::Geturl()
{
	return url;
}

double PRC::Getpr()
{
	return pr;
}

int PRC::Modipr(double value)
{
	pr = value;
	return 0;
}


int Calculator(std::map<std::string, PRC> &m)
{
	std::map<std::string, PRC>::iterator it;
	std::map<std::string, int>::iterator it2;
	std::map<std::string, PRC>::iterator it3;
	double value = 0.0;

	for (it = m.begin(); it != m.end(); it++)
	{
		value = it->second.Getpr();
		for (it2 = it->second.in.begin(); it2 != it->second.in.end(); it2++)
		{
			it3 = m.find(it2->first);
			if (it3->second.out.size() == 0)
				value += (1 - a) / m.size();
			else
				value += a*(it3->second.Getpr() / it3->second.out.size());
		}
		it->second.Modipr(value);
	}

	return 0;
}