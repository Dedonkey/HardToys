#include"Eve.h"


short Mysrand(void)
{
	srand((unsigned int)(time(NULL)));
	return 1;
}
short Myrand(void)
{
	char c, d;
	c = rand(); d = rand();
	if (c < 0)
		c = -c;
	if (d < 0)
		d = -d;
	return c*d;
}
short Gcd(int a,int b)
{
	int r0 = a, r1 = b, q = 0;
	int t = 0;
	while (r1 != 0)
	{
		q = (int)(r0 / r1);
		t = r1;
		r1 = r0 - q * r1;
		r0 = t;
	}

	return t;
}
short Numproc(short rangea,short rangeb)
{
	short arg = 0;

	arg = Myrand() % (rangeb - rangea + 1) + rangea;
	return arg;
}

int Fermat(short n, int safe)
{
	short t = 0;

	for (int i = 0; i < safe; i++)
	{
		t = Numproc(2, n - 2);
		t = Squmul(t, n - 1, n);
		if (t != 1)
			return 0;
	}

	return 1;
}

short Aproc(short *p,short rangea,short rangeb, int t)
{
	int k = 100;//100��ѭ������ɣ����򷵻�0
	while (k--)
	{
		*p = Numproc(rangea, rangeb);
		if (Fermat(*p, t))
			return 1;
	}
	return 0;
}

short PQproc(short *p, short *q, short rangea, short rangeb, int t)
{
	int k = 100;//100ѭ������ɣ����򷵻�0

	while (k--)
	{
		*p = Numproc(rangea, rangeb);
		*q = Numproc(rangea, rangeb);
		if (Fermat(*p, t) && Fermat(*q, t))
			if (Gcd(*p, *q))
				return 1;
	}

	return 0;
}

int Squmul(short x, int n, int mod)
{
	int z = 1;
	unsigned char c[32] = { 0 };
	int len = Num2bits(n, c);

	for (int i = len - 1; i >= 0; i--)
	{
		z = (z * z) % mod;
		if (c[i] == 1)
			z = z * x % mod;
	}
	
	return z;
}

int Exgcd(short x, int mod)
{
	int a0, b0, t0, t, q, r, temp;

	a0 = mod, b0 = x, t0 = 0, t = 1;
	if (b0 > a0)
		b0 = b0 % mod;
	if (b0 == a0)
		return 0;
	q = a0 / b0;
	r = a0 - q * b0;
	while (r > 0)
	{
		temp = (t0 - q * t) % mod;
		t0 = t;
		t = temp;
		a0 = b0;
		b0 = r;
		q = a0 / b0;
		r = a0 - q * b0;
	}
	if (b0 != 1)
		return 0;
	if (t < 0)
		return t + mod;
	return t;
}

