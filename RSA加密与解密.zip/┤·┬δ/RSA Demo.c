#include<stdio.h>
#include"Eve.h"


int main(void)
{
	extern int RSA(int *str, int len);
	extern int Initial(void);
	extern int UnRSA(int *str, int len);

	Initial();
	char c[10] = { '1','2','3','4','5','6','7','8','9','0' };
	int d[10] = { 0 };
	printf("����������\n");
	fgets(c, 10, stdin);
		for (int i = 0; i < 10; i++)
			d[i] = c[i];
		RSA(d, 10);
		printf("����:");
		for (int i = 0; i < 10; i++)
			printf("%c", d[i]); putchar('\n');
		UnRSA(d, 10);
		printf("����:");
		for (int i = 0; i < 10; i++)
			printf("%c", d[i]); putchar('\n');


	return 0;
}