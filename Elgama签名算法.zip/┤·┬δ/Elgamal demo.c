#include"Eve.h"

int main(void)
{
	extern int Initial(void);
	extern int Elgamal(int *str, int *gama, int *sigma);
	extern int Ver(int *str, int *gama, int *sigma);

	char c = 0;;
	int v = 0;
	Initial();
	int s = 0, gama = 0, sigma = 0;
	printf("������Ϣa\n");
	c = getchar();
	s = c;
	Elgamal(&s, &gama, &sigma);
	printf("gama = %d     sigma = %d\n", gama, sigma);

	if (v = Ver(&s, &gama, &sigma))
		printf("��֤�ɹ�\n");


	return 1;
}