#include"Eve.h"

int p = 0, A = 0, B = 0;
int a = 0;
short m = 0, n = 0;//����p���������� 
int k = 0;
int fi = 0;
int Initial(void)
{
	int cd = 0;

	Mysrand();
	Aproc(&p, RANGEA, RANGEB, SAFE);
	Aproc(&a, RANGEA, RANGEB, SAFE);
	fi = p - 1;
	for (cd = 2; cd <= sqrt(fi); cd++)
	{
		if (Squmul(cd, fi, p) == 1)
			break;
	}
	A = cd;
	B = Squmul(A, a, p);

	return 1;
}

int Elgamal(int *str, int *gama, int *sigma)
{
	int exgcd = 0;
	k = Numproc(RANGEA, p - 1);
	while (Gcd(k, p - 1) != 1)
		k = Numproc(RANGEA, p - 1);
	printf("���������k =  %d\n", k);
	*gama = Squmul(A, k, p);
	exgcd = Exgcd(k, p - 1);
	*sigma = ((*str - a * *gama)*exgcd) % (p - 1);
	if (*sigma < 0)
		*sigma += p - 1;
	return 1;
}

int Ver(int *str, int *gama, int *sigma)
{
	int v = Squmul(B, *gama, p);
	v *= Squmul(*gama, *sigma, p);
	v %= p;
	int x = Squmul(A, *str, p);

	if (v == x)
		return 1;
	return 0;
}