#include"Eve.h"

unsigned char roundkey[16][48] = { 0 };
unsigned char seedkey[7] = { 'i','t','i','s','k','e','y' };
int Keypbox(unsigned char *round, unsigned  char *roundkeyi)
{
	char pbox[48] = { 14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,41,52,34,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32 };
	for (int i = 0; i < SEEDLEN; i++)
		roundkeyi[i] = round[pbox[i] - 1];
	return 1;
}
int Setkey(void)
{
	char temp[8] = { 0 };
	extern char Getinitial(void);
	extern char *sgets(char *str, int max);

	printf("need to set key? press y to set,else use the default seed\n");
	if (Getinitial() == 'y')
	{
		printf("input the seed please(only first seven available\n");
		sgets(temp, 8);
	for (int i = 0; i < 7; i++)
		seedkey[i] = temp[i];
	}
	return 1;
}

int Roundkey()
{
	extern int Str2bits(unsigned char *str, int length, unsigned  char *bits, int team);
	extern int Depart(unsigned char *bits, int length, unsigned  char *l, unsigned  char *r);
	extern int Cls(unsigned char *bits, int length, int bias);
	int Combine(unsigned char *bits, int length, unsigned  char *l, unsigned  char *r);

	unsigned char sk[56] = { 0 };//����seedkey�ı��ر�ʾ���Լ�ÿ�ֵ�ԭʼ����Կ���ش�
	unsigned char c[28] = { 0 }, d[28] = { 0 };//��λ�͸�λ
	int bias = 0;

	Str2bits(seedkey, 7, sk, TEAM);
	Depart(sk, SEEDLEN, c, d);
	for (int i = 0; i < 16; i++)
	{
		switch (i)
		{
		case 0:case 1:case 8:case 15:bias = 1;
			break;
		default:bias = 2;
			break;
		}
		Cls(c, 28, bias); Cls(d, 28, bias);
		Combine(sk, SEEDLEN, c, d);
		Keypbox(sk, roundkey[i]);
	}

	return 1;
}